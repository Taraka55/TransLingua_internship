import streamlit as st
from google import genai
from dotenv import load_dotenv
import os
import random
from PIL import Image

# -------------------------
# Load API Key
# -------------------------
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
client = genai.Client(api_key=api_key)

# -------------------------
# Translation Function
# -------------------------
def translate_text(text, source_language, target_language):
    prompt = (
        f"Translate the following text from {source_language} "
        f"to {target_language}. Only return the translated text:\n\n{text}"
    )

    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt
    )

    return response.text


# -------------------------
# Page Configuration
# -------------------------
st.set_page_config(
    page_title="TransLingua",
    page_icon="🌍",
    layout="wide"
)

# -------------------------
# Light Professional Background
# -------------------------
st.markdown("""
<style>
.stApp {
    background: linear-gradient(120deg, #f6f9fc, #e3f2fd);
    font-family: 'Segoe UI', sans-serif;
}

.glass-box {
    background: rgba(255, 255, 255, 0.85);
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0px 10px 30px rgba(0,0,0,0.08);
}

h1 {
    text-align: center;
    color: #0d47a1;
}

.stButton>button {
    background: linear-gradient(90deg, #2196f3, #21cbf3);
    color: white;
    border-radius: 25px;
    padding: 10px 25px;
    border: none;
    font-weight: bold;
}

.stButton>button:hover {
    background: linear-gradient(90deg, #1976d2, #00bcd4);
}
</style>
""", unsafe_allow_html=True)

# -------------------------
# RANDOM IMAGE EVERY REFRESH
# -------------------------
image_folder = "images"

# Automatically read all images inside folder
image_files = [
    file for file in os.listdir(image_folder)
    if file.endswith((".png", ".jpg", ".jpeg"))
]

selected_image = random.choice(image_files)
image_path = os.path.join(image_folder, selected_image)

# -------------------------
# Layout
# -------------------------
col1, col2 = st.columns([1, 2])

with col1:
    if os.path.exists(image_path):
        img = Image.open(image_path)
        st.image(img, use_container_width=True)
    else:
        st.warning("No images found in images folder.")

with col2:
    st.markdown('<div class="glass-box">', unsafe_allow_html=True)

    st.title("🌍 TransLingua")
    st.write("AI Powered Multi-Language Translation Platform")

    text = st.text_area("Enter text to translate")

    languages = [
        "English",
        "Telugu",
        "Hindi",
        "Tamil",
        "Kannada",
        "Malayalam",
        "French",
        "German",
        "Spanish"
    ]

    source = st.selectbox("Source Language", languages)
    target = st.selectbox("Target Language", languages)

    if st.button("Translate"):
        if text.strip() == "":
            st.warning("Please enter some text.")
        elif source == target:
            st.warning("Source and Target languages cannot be the same.")
        else:
            with st.spinner("Translating..."):
                result = translate_text(text, source, target)
                st.success("Translation Complete ✅")
                st.write(result)

    st.markdown("</div>", unsafe_allow_html=True)

st.markdown("---")
st.caption("Built using Gemini 2.5 Flash Model 🚀")

